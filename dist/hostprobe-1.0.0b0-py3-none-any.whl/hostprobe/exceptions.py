class InvalidIp(ValueError):
    "An invalid ipaddr was given"

class ThresholdError(ValueError):
    "An error related to maximum and minumum error threshold"